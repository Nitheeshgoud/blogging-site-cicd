#!/bin/bash
cd /home/ubuntu/app
pkill -f "node server.js"